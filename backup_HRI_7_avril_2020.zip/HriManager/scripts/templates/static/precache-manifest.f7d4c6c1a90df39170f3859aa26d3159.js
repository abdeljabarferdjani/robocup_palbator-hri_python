self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "94931f12419d75fe6909abf4f4bca38c",
    "url": "./index.html"
  },
  {
    "revision": "f0e39af3776e2201e9a5",
    "url": "./static/css/main.1f6b1045.chunk.css"
  },
  {
    "revision": "80c093b7b3ac81be3be4",
    "url": "./static/js/2.376e2e38.chunk.js"
  },
  {
    "revision": "f0e39af3776e2201e9a5",
    "url": "./static/js/main.7846b0fe.chunk.js"
  },
  {
    "revision": "8c97409f0ee389fe75da",
    "url": "./static/js/runtime~main.d653cc00.js"
  },
  {
    "revision": "d78a4b0beafd6d71f69910508f465054",
    "url": "./static/media/internetError.d78a4b0b.svg"
  },
  {
    "revision": "34690a2b25e12dd8a245fa3b48524d54",
    "url": "./static/media/muteMicro.34690a2b.svg"
  },
  {
    "revision": "55978f426bfbde58d07fa197e7c57ef0",
    "url": "./static/media/pcProblem.55978f42.svg"
  }
]);