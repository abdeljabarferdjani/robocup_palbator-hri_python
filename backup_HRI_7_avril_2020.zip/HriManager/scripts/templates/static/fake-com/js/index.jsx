import React from 'react';
import ReactDOM from 'react-dom';
import routes from "./routes";


ReactDOM.render(routes, document.getElementById("content"));